import React, {Component} from 'react';
import Grid from '@material-ui/core/Grid';
import CircularprogressBar from '../Chart2js/circularProgress';
import LineChart from '../Chart2js/lineChart';
import {baseURL} from '../../Config.js';
import axios from 'axios';
import NumberClass from './NumberClass';

const headingGrid = {
		
};

const mainGrid = {
		width:'120px',
};

const leftcontentDiv = {
		
};

const rightcontentDiv = {
		
};

const footGrid = {
		height: '80px',
		margin:"3%",
		
};
const footlevel = {
		marginLeft:'7%',
		position:'absolute',
		marginTop:'0%'
		
		
};


class index extends Component{
	
	constructor(props) {
		super(props);
		this.state = {  data: {},
						label: [],
						graphData: [],
					    isLoading:true
					  };
	}
	
	async componentWillMount() {
		axios.get(baseURL+'inductsfortheday/'+ sessionStorage.getItem("username") +this.props.sorterRoute)
			 .then(res => {
			    console.log(res.data);
			    let label = res.data.inductsForTheDayList.map(list => list.currentDt);
			    let graphData = res.data.inductsForTheDayList.map(list => list.curr_value);
			    
			    console.log(graphData);
		        this.setState({ data: res.data,
		        				label: label,
		        				graphData: graphData,
					        	isLoading:false}); })
			.catch(function (error) {
				console.log(error);
		  });
	}
	
	render(){
		
		if(this.state.isLoading) {
			return(<Grid container></Grid>);
		} else {
			return (
					<Grid container spacing={2}>
						<Grid className="all-header-grid" item xs={12} sm={12}>
							<strong>Inducts for the day</strong>
						</Grid>
						<Grid xs={12} sm={4}>
							<div style={leftcontentDiv, {marginLeft: '10px'}}>
								<div style={{padding: '20px 0px 0px 0px'}}>
									<CircularprogressBar percentage={this.state.data.percentValue}/>
								</div>
							</div>
						</Grid>
						<Grid style={mainGrid} item xs={12} sm={8} container>
							<Grid item xs={12} sm={12}>
							<div style={rightcontentDiv}>
								<Grid container className="kpi-text-heading">
								<Grid item xs={12} sm={12}><span className="kpi-value-left"><NumberClass number={this.state.data.currentValue} /></span> /
								<label className="kpi-value-right">&nbsp;<NumberClass number={this.state.data.goalValue} /></label></Grid>
							</Grid>
						</div>
							</Grid>
							<Grid style={footGrid} item xs={12} sm={12}>
							<div style={footlevel}>Last 5 Days</div>
								<div className="lineChart1" style={footGrid}>
									<LineChart label={this.state.label} graphData={this.state.graphData} color={'green'}/>
								</div>
							</Grid>
						</Grid>
					</Grid>
			);
		}
	}
}
export default index;
