import React, { Component } from 'react';
import Header from '../../../login/Header';
import InductionStatusDetail from './InductionStatusDetail';
import Footer from '../../../login/Footer';
import Grid from '@material-ui/core/Grid';

import {baseURL} from '../../../../Config.js';
import axios from 'axios';

class index extends Component {
	
	constructor(props) {
		super(props);
		this.state = {  data: [],
					    isLoading:true
					  };
	}
	
	linkState = this.props.location.state === undefined ? '' : this.props.location.state.nextLink
			
	async componentWillMount() {
		axios.get(baseURL+'inductionstatus/'+ sessionStorage.getItem("username") )
			 .then(res => {
			    console.log(res.data);
			    this.setState({ data: res.data,
			    				isLoading:false}); 
			}).catch(function (error) {
				console.log(error);
		  });
	}
	
    render(){
    	if(this.state.isLoading) {
			return(<div> <Header/> <Grid container></Grid> <Footer /></div>);
		} else {
	      return(<div>
	      			<Header/>
	      				<InductionStatusDetail data={this.state.data} lastLink={this.linkState}/>
	      			<Footer />
	      		</div>
	      );
		}
    }
  }
export default index;
