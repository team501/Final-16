import React from 'react';
import {Link} from 'react-router-dom';

import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import './land.css'; 
import NumberClass from '../../NumberClass';

const headingFont = {
	    color: '#870038',
	    fontWeight: '400',
	    fontSize: '24px',
	    padding: '15px 0px 20px 0px'
};

const styles = theme => ({
  root: {
	  flexGrow: 1,
	  padding: '90px 20px 20px 15px',
	    overflowY: 'auto',
	    backgroundColor: theme.palette.background.default,
  },
  table: {
    minWidth: 400,
    border: '1px #E7EBE8',
  },
  row: {  
	  borderCollapse: '10px !important',
  },
});


function SimpleTable(props) {
  const { classes } = props;
  const rows = props.data; 
  return (
    <Paper className={classes.root}>
    <div className="breadScrum">Unit Sorter Dashboard >> {props.lastLink} >> <strong> Induction Status</strong> </div>
	<Grid className="chuteHeader" style={headingFont} item xs={12} sm={12}>
		<Link to={{ pathname: '/sorterdetails', state: { data: props.lastLink } }}><span className="glyphicon glyphicon-arrow-left"></span></Link> Induction Status
		
	</Grid>
    <div className="table-outer-induction">
      <Table className={classes.table}>
        <TableHead>
          <TableRow className="crowH">
            <TableCell className="cheader">{' '} </TableCell>
            <TableCell align="left" className="cheader"><strong>Runtime </strong></TableCell>
            <TableCell align="left" className="cheader"><strong>Total Inducts </strong></TableCell>
            <TableCell align="left" className="cheader"><strong>Induct/hour </strong></TableCell>
            <TableCell align="left" className="cheader"><strong>Utilization </strong></TableCell>
            <TableCell align="left" className="cheader"><strong>Peak Rate </strong></TableCell>
            <TableCell align="left" className="cheader"><strong>Min Rate </strong></TableCell>
            <TableCell align="left" className="cheader"><strong>Average Rate </strong></TableCell>
            <TableCell align="left" className="cheader"><strong>Current user </strong></TableCell>
            <TableCell align="left" className="cheader"><strong>Last Scan </strong></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map(row => {
            return (
              <TableRow key={row.id} className="crowH">
                <TableCell style={{backgroundColor: '#edad02'}} component="th" scope="row" className="crow1">
                  {'Station A1'}
                </TableCell>
                <TableCell align="left" className="crow1">{row.runtime}</TableCell>
                <TableCell align="left" className="crow1"><NumberClass number={row.total_inducts} /> </TableCell>
                <TableCell align="left" className="crow1"><NumberClass number={row.inducts_per_hour} /> </TableCell>
                <TableCell align="left" style={{color: '#edad02'}} className="crow1">
                	<NumberClass number={row.utilization} /> </TableCell>
                <TableCell align="left" className="crow1"><NumberClass number={row.peak_rate} /> </TableCell>
                <TableCell align="left" className="crow1"><NumberClass number={row.min_rate} /> </TableCell>
                <TableCell align="left" className="crow1"><NumberClass number={row.avg_rate} /> </TableCell>
                <TableCell align="left" className="crow1">{row.current_usr}</TableCell>
                <TableCell align="left" className="crow1">{row.last_scan}</TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
      </div>
    </Paper>
  );
}

SimpleTable.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(SimpleTable);