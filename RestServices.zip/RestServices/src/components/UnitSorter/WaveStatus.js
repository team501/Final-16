import React, {Component} from 'react';
import Grid from '@material-ui/core/Grid';
import ProgressBar from '../Chart2js/ProgressBar';
import { Label  } from 'react-bootstrap';
import {baseURL} from '../../Config.js';
import axios from 'axios';
import NumberClass from './NumberClass';

const headingGrid = {
		
};

const headingGrid2 = {
		textAlign: 'right',
		height: '25px',
		fontSize: 'large',
		padding: '10px'
};

const mainGrid = {
		padding: '40px',
		height: '40px',
};

const mainGridLegends = {
		height: '40px',
		fontSize: 'xx-large'
};

class index extends Component {
	
	constructor(props) {
		super(props);
		this.state = {  allocated: '',
						id: '',
						remaining: '',
						sorted: '',
						units: '',
						userid: '',
						wave: '',
					    isLoading:true
					  };
	}	
	
	async componentWillMount() {
		axios.get(baseURL+'wavestatustoday/'+ sessionStorage.getItem("username") )
			 .then(res => {
			    console.log(res);
		        this.setState({ allocated: res.data.allocated,
								id: res.data.id,
								remaining: res.data.remaining,
								sorted: res.data.sorted,
								units: res.data.units,
								userid: res.data.userid,
								wave: res.data.wave,
								allocatedPercentage: res.data.allocatedPercentage,
								sortedPercentage: res.data.sortedPercentage,
								remainingPercentage: res.data.remainingPercentage,
					        	isLoading:false});
		}).catch(function (error) {
		    console.log(error);
		  });
	}
	
	render() { 
		if(this.state.isLoading) {
			return(<Grid container></Grid>);
		} else {
			return(
					<Grid container>
					<Grid className="all-header-grid" item xs={12} sm={6}>
						<strong>Wave status today</strong>
					</Grid>
					<Grid style={headingGrid2} item xs={12} sm={6}>
						Wave <strong><NumberClass number={this.state.wave} /></strong> &nbsp; &nbsp; Units <NumberClass number={this.state.units} />
					</Grid>
					<Grid style={mainGrid} item xs={12} sm={12}>
						<ProgressBar allocated={this.state.allocatedPercentage} 
									 sorted={this.state.sortedPercentage}
									 remaining={this.state.remainingPercentage}/>
					</Grid>
					<Grid style={{textAlign: 'center'}}container>
						<Grid item xs={4} sm={4}>
							<Label bsStyle="success success-wev-status">Allocated</Label>{' '}
							<Grid style={mainGridLegends} item xs={12} sm={12}>
								(<NumberClass number={this.state.allocated} />)
							</Grid>
						</Grid>
						<Grid item xs={4} sm={4}>
							<Label bsStyle="warning warning-wev-status">Sorted</Label>{' '}
							<Grid style={mainGridLegends} item xs={12} sm={12}>
								(<NumberClass number={this.state.sorted} />)
							</Grid>
						</Grid>
						<Grid item xs={4} sm={4}>
							<Label bsStyle="danger danger-status">Remaining</Label>
							<Grid style={mainGridLegends} item xs={12} sm={12}>
							(<NumberClass number={this.state.remaining} />)
							</Grid>
						</Grid>
					</Grid>
				</Grid>
			);
		}
	}
}
export default index;